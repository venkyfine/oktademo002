//
//  LoginViewController.swift
//  OktaDemo

import UIKit
import OktaAuthSdk

class LoginViewController: UIViewController {

    @IBOutlet weak var tfUsername: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    
    var viewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func loginPressed(_ sender: UIButton) {
        
        let successBlock: (OktaAuthStatus) -> Void = { [weak self] status in
            switch status.statusType {
            case .unauthenticated:
                print("UnAuthenticated")
            case .passwordWarning:
                print("passwordWarning")
            case .passwordExpired:
                print("passwordExpired")
            case .recovery:
                print("recovery")
            case .recoveryChallenge:
                print("recoveryChallenge")
            case .passwordReset:
                print("passwordReset")
            case .lockedOut:
                print("lockedOut")
            case .MFAEnroll:
                print("MFAEnroll")
            case .MFAEnrollActivate:
                print("MFAEnrollActivate")
            case .MFARequired:
                print("MFARequired")
            case .MFAChallenge:
                print("MFAChallenge")
            case .success:
                print("success")
            case .unknown(_):
                print("unknown")
            }
            self?.showAlert(title: "Success", message: "\(status.statusType)", buttons: ["Ok"], actionHandler: { idx, title in
            
                
            })
        }

        let errorBlock: (OktaError) -> Void = { [weak self] error in
            self?.showAlert(title: "Error", message: error.localizedDescription, buttons: [], actionHandler: { idx, title in
                
            })
        }
        
        viewModel.login(username: tfUsername.text!, password: tfPassword.text!, onStatusChange: successBlock, errorBlock)
    }

}

