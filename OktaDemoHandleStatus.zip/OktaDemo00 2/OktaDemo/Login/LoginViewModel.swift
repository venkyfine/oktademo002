//
//  LoginViewModel.swift
//  OktaDemo

import UIKit
import OktaAuthSdk

struct LoginViewModel {

    func login(username: String, password: String,  onStatusChange: @escaping (OktaAuthStatus) -> Void, _ error: @escaping (_ error: OktaError) -> Void) {
        OktaManager.shared.login(username: username, password: password, onStatusChange: onStatusChange, error)
       
    }
}
