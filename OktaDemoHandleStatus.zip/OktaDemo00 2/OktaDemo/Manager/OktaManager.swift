//
//  OktaManager.swift
//  OktaDemo

import Foundation
import OktaAuthSdk
import OktaOidc

class OktaManager {
    private init() { }
    private var oktaOidc: OktaOidc? = try? OktaOidc()
    var authState: OktaOidcStateManager?

    static var shared = OktaManager()

    func login(username: String, password: String, onStatusChange: @escaping (OktaAuthStatus) -> Void, _ error: @escaping (_ error: OktaError) -> Void) {
        OktaAuthSdk.authenticate(with:URL(string: "https://dev-21869016.okta.com")!, username: username, password: password, onStatusChange: onStatusChange,onError: error)
    }

    func getUser(completion: @escaping (_ user: [String: Any]?, _ error: Error?) -> Void) {
        authState?.getUser({ response, error in
            if error != nil {
                completion(nil, error)
            }
            completion(response, nil)
        })
    }

    func isTokenValid(token: String?, completion : @escaping ((_ isValid: Bool, _ error: Error?) -> Void)) {
        authState?.introspect(token: token, callback: { payload, error in
            guard let isValid = payload?["active"] as? Bool else {
                completion(false, error)
              return
            }
            completion(isValid, error)
        })
    }

    func handleSuccess(sessionToken: String, completion: @escaping (_ tokenManager: OktaOidcStateManager?, _ error: Error?) -> Void) {
        oktaOidc?.authenticate(withSessionToken: sessionToken, callback: { manager, error in
            guard let manager = manager else {
                completion(nil, error)
                return
            }
            do {
                self.authState = manager
                let encodedData: Data = try NSKeyedArchiver.archivedData(withRootObject: manager, requiringSecureCoding: false)
                completion(manager, nil)
            } catch let error {
                completion(nil, error)
            }
        })
    }

    func renewToken(completion: @escaping (_ isTokenValid: Bool, _ error: Error?) -> Void) {
        authState?.renew { manager, error in
            if error == nil {
                if let manager = manager {
                    self.authState = manager
                    do {
                        completion(true, nil)
                    } catch let error {
                        completion(false, error)
                    }
                } else {
                    completion(false, error)
                }
            } else {
                completion(false, error)
            }
        }
    }
}
